def calculate_total_distance(initial_height, num_bounces):
    """
    Function to calculate the total distance traveled by the bouncing ball.
    
    Args:
        initial_height: Initial height from which the ball is dropped (in feet)
        num_bounces: Number of times the ball is allowed to continue bouncing
        
    Returns:
        Total distance traveled by the ball (in feet)
    """
    bounciness_index = 0.6
    total_distance = initial_height  # Distance when the ball is dropped
    
    for _ in range(num_bounces):
        # Calculate the distance traveled during the bounce
        bounce_distance = initial_height * bounciness_index
        
        # Update the total distance
        total_distance += bounce_distance
        
        # Update the initial height for the next bounce
        initial_height = bounce_distance
    
    return total_distance

def main():
    """
    Main function to take user input and calculate the total distance traveled by the ball.
    """
    try:
        initial_height = float(input("Enter the initial height from which the ball is dropped (in feet): "))
        num_bounces = int(input("Enter the number of times the ball is allowed to bounce: "))
        
        if initial_height <= 0 or num_bounces < 0:
            print("Initial height should be positive and the number of bounces should be non-negative.")
        else:
            total_distance = calculate_total_distance(initial_height, num_bounces)
            print(f"The total distance traveled by the ball is {total_distance:.2f} feet.")
            
    except ValueError:
        print("Please enter valid numerical values for the initial height and number of bounces.")

if __name__ == "__main__":
    main()
