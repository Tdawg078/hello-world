# stats.py

def mean(numbers):
    """
    Computes the mean (average) of a list of numbers.
    
    Args:
    - numbers (list of float/int): List of numbers
    
    Returns:
    - float: Mean of the numbers, or 0 if the list is empty
    """
    if not numbers:
        return 0
    return sum(numbers) / len(numbers)

def median(numbers):
    """
    Computes the median of a list of numbers.
    
    Args:
    - numbers (list of float/int): List of numbers
    
    Returns:
    - float: Median of the numbers, or 0 if the list is empty
    """
    if not numbers:
        return 0
    
    sorted_numbers = sorted(numbers)
    n = len(sorted_numbers)
    middle_index = n // 2
    
    if n % 2 == 0:
        # Even number of elements, average of middle two
        return (sorted_numbers[middle_index - 1] + sorted_numbers[middle_index]) / 2
    else:
        # Odd number of elements, middle element
        return sorted_numbers[middle_index]

def mode(numbers):
    """
    Computes the mode of a list of numbers.
    
    Args:
    - numbers (list of float/int): List of numbers
    
    Returns:
    - float: Mode of the numbers, or 0 if the list is empty or if there's no mode
    """
    if not numbers:
        return 0
    
    from collections import Counter
    counts = Counter(numbers)
    max_count = max(counts.values())
    mode = [num for num, count in counts.items() if count == max_count]
    
    if len(mode) == len(numbers):
        return 0  # All numbers are the same (no mode)
    else:
        return mode[0]

def main():
    # Test the functions with a sample list
    numbers = [3, 1, 2, 2, 3, 4, 5, 6, 6]
    
    print(f"List of numbers: {numbers}")
    print(f"Mean: {mean(numbers)}")
    print(f"Median: {median(numbers)}")
    print(f"Mode: {mode(numbers)}")

if __name__ == "__main__":
    main()
