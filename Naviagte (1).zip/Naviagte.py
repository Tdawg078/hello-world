def navigate_file(filename):
    # Attempt to open the file
    try:
        with open(filename, 'r') as file:
            lines = file.readlines()  # Read all lines into a list
    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
        return
    
    num_lines = len(lines)

    while True:
        # Print number of lines in the file
        print(f"\nThe file '{filename}' contains {num_lines} lines.")

        # Prompt user for a line number
        try:
            line_number = int(input("Enter a line number (1 to {}), or 0 to quit: ".format(num_lines)))
        except ValueError:
            print("Invalid input. Please enter a number.")
            continue
        
        if line_number == 0:
            print("Exiting the program.")
            break
        elif 1 <= line_number <= num_lines:
            # Print the selected line (line_number - 1 to adjust for zero-based index)
            print(f"Line {line_number}: {lines[line_number - 1]}")
        else:
            print(f"Invalid input. Please enter a number between 1 and {num_lines}.")

if __name__ == "__main__":
    filename = input("Enter the filename: ")
    navigate_file(filename)
