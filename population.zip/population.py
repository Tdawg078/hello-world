def predict_population(initial_population, growth_rate, growth_period, total_hours):
    """
    Function to predict population growth.
    
    Args:
        initial_population: Initial number of organisms
        growth_rate: Rate of growth (a real number greater than 0)
        growth_period: Number of hours it takes to achieve the growth rate
        total_hours: Total number of hours for which the population grows
        
    Returns:
        Predicted total population after the specified number of hours
    """
    current_population = initial_population
    hours_elapsed = 0

    while hours_elapsed < total_hours:
        current_population *= growth_rate
        hours_elapsed += growth_period

    return current_population

def main():
    """
    Main function to take user input and predict the total population.
    """
    try:
        initial_population = int(input("Enter the initial number of organisms: "))
        growth_rate = float(input("Enter the growth rate (a real number greater than 0): "))
        growth_period = int(input("Enter the number of hours it takes to achieve this growth rate: "))
        total_hours = int(input("Enter the total number of hours for which the population grows: "))
        
        if initial_population <= 0 or growth_rate <= 0 or growth_period <= 0 or total_hours <= 0:
            print("All inputs should be positive values.")
        else:
            predicted_population = predict_population(initial_population, growth_rate, growth_period, total_hours)
            print(f"The predicted total population after {total_hours} hours is: {predicted_population}")
            
    except ValueError:
        print("Please enter valid numerical values for all inputs.")

if __name__ == "__main__":
    main()
