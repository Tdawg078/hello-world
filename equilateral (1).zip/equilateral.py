def is_equilateral(side1, side2, side3):
    """
    Function to determine if a triangle is equilateral.
    
    Args:
        side1, side2, side3: Lengths of the sides of the triangle
        
    Returns:
        True if the triangle is equilateral, False otherwise
    """
    if side1 == side2 == side3:
        return True
    else:
        return False

def main():
    """
    Main function to take user input and determine if the triangle is equilateral.
    """
    try:
        side1 = float(input("Enter the length of side 1: "))
        side2 = float(input("Enter the length of side 2: "))
        side3 = float(input("Enter the length of side 3: "))
        
        if side1 <= 0 or side2 <= 0 or side3 <= 0:
            print("Length of sides should be positive.")
        elif side1 + side2 <= side3 or side2 + side3 <= side1 or side1 + side3 <= side2:
            print("These side lengths cannot form a triangle.")
        elif is_equilateral(side1, side2, side3):
            print("The triangle is an equilateral triangle.")
        else:
            print("The triangle is not an equilateral triangle.")
            
    except ValueError:
        print("Please enter valid numerical values for the side lengths.")

if __name__ == "__main__":
    main()
