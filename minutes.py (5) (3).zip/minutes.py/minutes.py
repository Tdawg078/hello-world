def years_to_minutes(years):
    # Define constants for conversions
    minutes_per_hour = 60
    hours_per_day = 24
    days_per_year = 365

    # Calculate total minutes
    total_minutes = years * days_per_year * hours_per_day * minutes_per_hour

    return total_minutes

def main():
    # Input number of years
    years = float(input("Enter number of years: "))

    # Calculate minutes
    total_minutes = years_to_minutes(years)

    # Print the result
    print("There are", total_minutes, "minutes in", years, "years.")

if __name__ == "__main__":
    main()


      